import java.util.*;

class Question3
{
   public static void main ( String args [] )
   {
      System.out.println (new Shape ("Pentagon", "Blue"));
      System.out.println (new Circle ("Circle", "Purple",  3));
      System.out.println (new Rectangle ("Rectangle", "Red", 6, 8));
   }
}

class Seller {
   String id;
   String name;
   String location;
   String product;
   String unitPrice;
   int numberOfUnits;
   }
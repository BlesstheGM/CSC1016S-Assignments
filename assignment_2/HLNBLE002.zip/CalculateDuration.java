import java.util.Scanner;
// Program to calculate duration between two distinct time points
// Name: Blessing Hlongwane
// Student Number: HLNBLE002
// Date: 31 July 2023

class CalculateDuration{
   public static void main(String [] args){
      Scanner question = new Scanner(System.in);
      String time_A;
      System.out.println("Enter time A:");
      time_A = question.nextLine();
      Time time_1 = new Time(time_A); // Creating Time object for Time A
      System.out.println("Enter time B:");
      String time_B;
      time_B = question.nextLine();
      Time time_2 = new Time(time_B); // Creating time object for Time B
      Duration d = time_2.subtract(time_1); // Calculating the duration
      System.out.println("The time " + time_2.toString() + " occurs " + d.intValue("minute") + " minutes after the time " + time_1.toString() + ".");
 
   }
}
import java.util.Scanner;

public class CarParkSim {
    public static void main(String[] args) {
        final Scanner keyboard = new Scanner(System.in);
        Clock clock = new Clock(new Time("00:00"));
        Register register = new Register();
        TariffTable tariffTable = new TariffTable(100);
        Currency currency = new Currency("R", "ZAR", 100);
        String rate;

        // Populate the TariffTable with tariffs
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 0), new Duration("minute", 30)), new Money("R10", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("minute", 30), new Duration("hour", 1)), new Money("R15", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 1), new Duration("hour", 3)), new Money("R20", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 3), new Duration("hour", 4)), new Money("R30", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 4), new Duration("hour", 5)), new Money("R40", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 5), new Duration("hour", 6)), new Money("R50", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 6), new Duration("hour", 8)), new Money("R60", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 8), new Duration("hour", 10)), new Money("R70", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 10), new Duration("hour", 12)), new Money("R90", currency));
        tariffTable.addTariff(new TimePeriod(new Duration("hour", 12), new Duration("hour", 24)), new Money("R100", currency));

        System.out.println("Car Park Simulator");
        System.out.println("The current time is " + clock.examine() + ".");
        System.out.println("Commands: tariffs, advance {minutes}, arrive, depart, quit.");
        System.out.print(">");

        String input = keyboard.next().toLowerCase();
        while (!input.equals("quit")) {
            if (input.equals("advance")) {
                int advance = keyboard.nextInt();
                clock.advance(new Duration("minute", advance));
                System.out.println("The current time is " + clock.examine() + ".");
            } else if (input.equals("arrive")) {
                String UID_One = UIDGenerator.makeUID();
                Ticket myTicket = new Ticket(clock.examine());
                register.add(myTicket);
                System.out.print("Ticket issued: ");
                System.out.println(myTicket.toString() + ".");
            } else if (input.equals("depart")) {
                String departTicket = keyboard.next();
                if (register.contains(departTicket)) {
                    Ticket ticket = register.retrieve(departTicket);
                    System.out.println("Ticket details: " + ticket.toString() + ".");
                    System.out.println("Current time: " + clock.examine() + ".");
                    Duration duration = ticket.age(clock.examine());
                    String ourDuration = duration.format(duration, "minute");
                    System.out.println("Duration of stay: " + ourDuration + ".");
                    
                    // Get the tariff for the calculated duration and print it
                    Money tariff = tariffTable.getTariff(duration);
                    System.out.println("Cost of stay : " + tariff.toString() + ".");
                } else {
                    System.out.println("Invalid ticket ID.");
                }
            } else if (input.equals("tariffs")) {
                // Print the list of parking tariffs from the TariffTable
                System.out.println(tariffTable.toString());
            } else {
                System.out.println("That command is not recognized.");
                System.out.println("Commands: advance <minutes>, arrive, depart, tariffs, quit.");
            }
            System.out.print(">");
            input = keyboard.next().toLowerCase();
        }
        System.out.println("Goodbye.");
    }
}


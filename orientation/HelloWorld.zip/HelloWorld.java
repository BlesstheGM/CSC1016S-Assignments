// My First Program
// Name: Blessing Hlongwane
// Student Number: HLNBLE002
// Date: 31 July 2023

class HelloWorld{
   public static void main(String [] args){
      System.out.println("Hello World");
   }
}